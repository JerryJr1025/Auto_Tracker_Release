@echo off
REM Ver 0.0.5 Alpha || 2026-09-07 || JBallados
REM Ver 0.0.6 Alpha || 2026-09-07 || JBallados
title Prototype Tracker Server Engine Ver 0.0.6 Alpha

:START
cls

set "TARGET_DIR=%USERPROFILE%\Desktop\JobTrackerServer"
set "SETUP_MARKER=%TARGET_DIR%\.setup_complete"
set "TAMPERMONKEY_PROMPT_MARKER=%TARGET_DIR%\.tampermonkey_prompted"
set "INSTALL_SCRIPT_MARKER=%TARGET_DIR%\.install_tampermonkey_script"
if not defined TRACKER_MODE set "TRACKER_MODE=1"
call :CHECK_FIRST_TIME_SETUP
if errorlevel 1 exit /b 1

:MAIN_MENU
cls

echo ==================================================
echo        PROTOTYPE TASK TRACKER
echo ==================================================
echo.
echo Environment : Windows
echo.
echo [1] Start Tracker
echo [2] Mode 1
echo [3] Mode 2
echo [4] Reset
echo [5] Reports
echo [6] Setup / Repair
echo [7] Tampermonkey
echo [8] Exit
echo.
echo Current Mode : %TRACKER_MODE%
echo ==================================================

choice /C 12345678 /N /M "Select option: "

if errorlevel 8 goto MENU_EXIT
if errorlevel 7 goto MENU_TAMPERMONKEY
if errorlevel 6 goto MENU_SETUP
if errorlevel 5 goto MENU_REPORTS
if errorlevel 4 goto MENU_RESET
if errorlevel 3 goto SELECT_MODE2
if errorlevel 2 goto SELECT_MODE1
if errorlevel 1 goto START_TRACKER

:SELECT_MODE1
set "TRACKER_MODE=1"
echo.
echo [OK] Mode 1 selected.
timeout /t 1 /nobreak >nul
goto MAIN_MENU

:SELECT_MODE2
set "TRACKER_MODE=2"
echo.
echo [OK] Mode 2 selected.
timeout /t 1 /nobreak >nul
goto MAIN_MENU

:MENU_RESET
echo.
echo [INFO] Reset functionality will be implemented in a later part.
timeout /t 2 /nobreak >nul
goto MAIN_MENU

:MENU_REPORTS
echo.
echo [INFO] Reports functionality will be implemented in a later part.
timeout /t 2 /nobreak >nul
goto MAIN_MENU


:MENU_SETUP
cls
call :RUN_SETUP
if errorlevel 1 (
    echo.
    echo [ERROR] Setup / Repair did not complete.
    pause
    goto MAIN_MENU
)
>"%SETUP_MARKER%" echo Setup completed on %DATE% %TIME%
echo.
echo [OK] Setup / Repair completed.
pause
goto MAIN_MENU

:MENU_TAMPERMONKEY
cls
echo ==================================================
echo              TAMPERMONKEY
echo ==================================================
echo.
echo [1] Install Tampermonkey Extension
echo [2] Install Auto Tracker Script
echo [3] Update Auto Tracker Script
echo [4] Back
echo.
choice /C 1234 /N /M "Select option: "
if errorlevel 4 goto MAIN_MENU
if errorlevel 3 goto QUEUE_TAMPERMONKEY_UPDATE
if errorlevel 2 goto QUEUE_TAMPERMONKEY_INSTALL
if errorlevel 1 goto OPEN_TAMPERMONKEY

:OPEN_TAMPERMONKEY
start "" "https://www.tampermonkey.net/"
goto MENU_TAMPERMONKEY

:QUEUE_TAMPERMONKEY_INSTALL
call :QUEUE_TAMPERMONKEY_SCRIPT
if errorlevel 1 (
    pause
    goto MENU_TAMPERMONKEY
)
echo [OK] Userscript installer will open after the controller starts.
timeout /t 1 /nobreak >nul
goto START_TRACKER

:QUEUE_TAMPERMONKEY_UPDATE
call :QUEUE_TAMPERMONKEY_SCRIPT
if errorlevel 1 (
    pause
    goto MENU_TAMPERMONKEY
)
echo [OK] Userscript updater will open after the controller starts.
timeout /t 1 /nobreak >nul
goto START_TRACKER

:CHECK_FIRST_TIME_SETUP
if exist "%SETUP_MARKER%" exit /b 0
cls
echo ==================================================
echo          AUTO TRACKER FIRST-TIME SETUP
echo ==================================================
echo.
echo This computer has not completed Auto Tracker setup.
echo The setup can install/check Node.js, npm, ExcelJS,
echo and open the official Tampermonkey installation page.
echo.
choice /C YN /N /M "Run first-time setup now? [Y/N]: "
if errorlevel 2 exit /b 1
call :RUN_SETUP
if errorlevel 1 exit /b 1
>"%SETUP_MARKER%" echo Setup completed on %DATE% %TIME%
exit /b 0

:RUN_SETUP
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
echo.
echo ==================================================
echo              SETUP / REPAIR
echo ==================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
    echo Node.js: NOT INSTALLED
    choice /C YN /N /M "Allow Auto Tracker to install Node.js LTS? [Y/N]: "
    if errorlevel 2 exit /b 1
    where winget >nul 2>nul
    if errorlevel 1 (
        echo [INFO] Windows Package Manager was not found.
        echo Opening the official Node.js download page.
        start "" "https://nodejs.org/en/download"
        echo Install Node.js LTS, then run Auto_Tracker.bat again.
        pause
        exit /b 1
    )
    winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    set "PATH=%PATH%;%ProgramFiles%\nodejs"
) else (
    echo Node.js: OK
)

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js is still unavailable.
    echo Restart Auto_Tracker.bat after installation completes.
    pause
    exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
    echo [ERROR] npm was not found even though Node.js is installed.
    echo Repair or reinstall Node.js LTS and try again.
    pause
    exit /b 1
)
echo npm: OK

if exist "%~dp0package.json" copy /Y "%~dp0package.json" "%TARGET_DIR%\package.json" >nul
if exist "%~dp0package-lock.json" copy /Y "%~dp0package-lock.json" "%TARGET_DIR%\package-lock.json" >nul
cd /d "%TARGET_DIR%"
if not exist package.json (
    >package.json echo {
    >>package.json echo   "dependencies": {
    >>package.json echo     "exceljs": "^4.4.0"
    >>package.json echo   }
    >>package.json echo }
)

echo Installing/verifying Auto Tracker dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 (
    echo [ERROR] npm install failed.
    exit /b 1
)
node -e "require('exceljs')" >nul 2>nul
if errorlevel 1 (
    echo [ERROR] ExcelJS verification failed.
    exit /b 1
)
echo ExcelJS: OK

call :SYNC_TAMPERMONKEY_SOURCE

if not exist "%TAMPERMONKEY_PROMPT_MARKER%" (
    echo.
    choice /C YN /N /M "Open the official Tampermonkey installation page? [Y/N]: "
    if not errorlevel 2 (
        start "" "https://www.tampermonkey.net/"
        echo Install Tampermonkey in your browser, then return here.
        pause
    )
    >"%TAMPERMONKEY_PROMPT_MARKER%" echo Tampermonkey prompt completed
)

if exist "%TARGET_DIR%\Tampermonkey_Modifications\TamperMonkey Mods" (
    choice /C YN /N /M "Open the Auto Tracker userscript when the controller starts? [Y/N]: "
    if not errorlevel 2 >"%INSTALL_SCRIPT_MARKER%" echo pending
)
exit /b 0

:SYNC_TAMPERMONKEY_SOURCE
if not exist "%TARGET_DIR%\Tampermonkey_Modifications" mkdir "%TARGET_DIR%\Tampermonkey_Modifications"
if exist "%~dp0Tampermonkey_Modifications\TamperMonkey Mods" (
    copy /Y "%~dp0Tampermonkey_Modifications\TamperMonkey Mods" "%TARGET_DIR%\Tampermonkey_Modifications\TamperMonkey Mods" >nul
)
exit /b 0

:QUEUE_TAMPERMONKEY_SCRIPT
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
call :SYNC_TAMPERMONKEY_SOURCE
if not exist "%TARGET_DIR%\Tampermonkey_Modifications\TamperMonkey Mods" (
    echo [ERROR] TamperMonkey Mods was not found in the designated folder.
    exit /b 1
)
>"%INSTALL_SCRIPT_MARKER%" echo pending
exit /b 0

:START_TRACKER
cls

set "BACKUP_DIR=%TARGET_DIR%\Backups"
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
call :SYNC_TAMPERMONKEY_SOURCE
cd /d "%TARGET_DIR%"
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do if not defined LDT set "LDT=%%I"

if defined LDT (
    set "BACKUP_TIMESTAMP=%LDT:~0,8%_%LDT:~8,6%"
) else (
    set "BACKUP_TIMESTAMP=%RANDOM%_%RANDOM%"
)

set "CURRENT_BACKUP=%BACKUP_DIR%\%BACKUP_TIMESTAMP%"

if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
if not exist "%CURRENT_BACKUP%" mkdir "%CURRENT_BACKUP%"

if exist server.js (
    copy /Y "server.js" "%CURRENT_BACKUP%\server.js" >nul
)

if exist stats.json (
    copy /Y "stats.json" "%CURRENT_BACKUP%\stats.json" >nul
)

if exist dashboard.html (
    copy /Y "dashboard.html" "%CURRENT_BACKUP%\dashboard.html" >nul
)

if exist dashboard.js (
    copy /Y "dashboard.js" "%CURRENT_BACKUP%\dashboard.js" >nul
)

if exist dashboard.css (
    copy /Y "dashboard.css" "%CURRENT_BACKUP%\dashboard.css" >nul
)

if exist Logs (
    xcopy /E /I /Y "Logs" "%CURRENT_BACKUP%\Logs" >nul
)

if exist Reports (
    xcopy /E /I /Y "Reports" "%CURRENT_BACKUP%\Reports" >nul
)

echo Backup: %CURRENT_BACKUP%

if exist server.js del server.js

for /f "tokens=1 delims=:" %%A in ('findstr /n /c:"___JS_START___" "%~f0"') do set "startLine=%%A"
const http = require('http');
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const {
    exec
} = require('child_process');
const jobTasks = {};

// =========================================
// FUNCTION DEBUG LOG
// Search: debugLog
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
const debugLog = (...args) => {

    if (process.env.TRACKER_DEBUG === '1') console.log(...args);

};
const ExcelJS = require("exceljs");
let trackingMode = Number(process.env.TRACKER_MODE) || null;
const statsFile = path.join(__dirname, 'stats.json');
const DATA_DIR = __dirname;
const mode2StatsFile = path.join(DATA_DIR, "mode2_stats.json");
const logsFolder = path.join(__dirname, "Logs");
const reportsFolder = path.join(__dirname, "Reports");
const tampermonkeyScriptFile = path.join(__dirname, "Tampermonkey_Modifications", "TamperMonkey Mods");
const installTampermonkeyMarker = path.join(__dirname, ".install_tampermonkey_script");
if (!fs.existsSync(reportsFolder)) {
    fs.mkdirSync(reportsFolder, {
        recursive: true
    });
}
if (!fs.existsSync(logsFolder)) {
    fs.mkdirSync(logsFolder);
}
const SHIFT = {
    interval1: {
        name: "Interval 1",
        startHour: 15,
        endHour: 17
    },
    interval2: {
        name: "Interval 2",
        startHour: 17,
        endHour: 19
    },
    interval3: {
        name: "Interval 3",
        startHour: 19,
        endHour: 21,
        endMinute: 30
    },
    breakMinutes: 30
};
let allTimeTasks = 0;
let totalTaskCompleted = 0;
let totalJobsCompleted = 0;
let trackerStartupComplete = false;
let mode2TaskCompleted = 0;
let mode2JobsCompleted = 0;
let mode2DeletedBoxes = 0;
let mode2EmptyAreaConfirmation = 0;
let mode2EmptyAreaNoMatchFound = 0;
let mode2UnblurredPerson = 0;
let mode2SkippedTask = 0;
let mode2Stats = {
    mode2TaskCompleted: 0,
    mode2JobsCompleted: 0,
    mode2DeletedBoxes: 0,
    mode2EmptyAreaConfirmation: 0,
    mode2EmptyAreaNoMatchFound: 0,
    mode2UnblurredPerson: 0,
    mode2SkippedTask: 0
};

// =========================================
// FUNCTION SYNC MODE2 STATS
// Search: syncMode2Stats
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function syncMode2Stats() {

    mode2Stats.mode2DeletedBoxes = mode2DeletedBoxes;
    mode2Stats.mode2TaskCompleted = mode2TaskCompleted;
    mode2Stats.mode2JobsCompleted = mode2JobsCompleted;
    mode2Stats.mode2EmptyAreaConfirmation = mode2EmptyAreaConfirmation;
    mode2Stats.mode2EmptyAreaNoMatchFound = mode2EmptyAreaNoMatchFound;
    mode2Stats.mode2UnblurredPerson = mode2UnblurredPerson;
    mode2Stats.mode2SkippedTask = mode2SkippedTask;

}
let completedJobs = [];
let currentJobId = "";
let currentJobUrl = "";
let currentJobDescription = "";
let jobStartedAt = Date.now();
let jobConfirmed = false;
const idleSessions = [];
let lastTotalTasksDone = 0;
let lastLogTimePH = "RESET DONE";
let lastStatusPH = "ACTIVE";
let idleStartTime = null;
let idleStartDisplay = "";
let totalIdleSeconds = 0;
let totalActiveSeconds = 0;
let lastJobFinished = null;
let clients = [];
let idleReason = "Unknown";
let pendingJobId = "";
let pendingJobUrl = "";
let pendingJobDescription = "";
const processedSubmitRequests = new Map();
const REQUEST_ID_EXPIRY_MS = 5 * 60 * 1000;

// =========================================
// FUNCTION CLEANUP PROCESSED SUBMIT REQUESTS
// Search: cleanupProcessedSubmitRequests
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function cleanupProcessedSubmitRequests() {

    const now = Date.now();
    for (const [requestId, timestamp] of processedSubmitRequests) {
        if (now - timestamp > REQUEST_ID_EXPIRY_MS) {
            processedSubmitRequests.delete(requestId);
        }
    }

}
let intervalHistory = [];
let currentIntervalNumber = 1;
let currentInterval = {
    number: 1,
    started: Date.now(),
    ended: null,
    tasks: 0,
    jobs: 0,
    jobRecords: []
};
let intervalStats = {
    interval1: {
        jobs: [],
        tasks: 0,
        idle: 0,
        active: 0
    },
    interval2: {
        jobs: [],
        tasks: 0,
        idle: 0,
        active: 0
    },
    interval3: {
        jobs: [],
        tasks: 0,
        idle: 0,
        active: 0
    }
};
let onBreak = false;
let breakTimer = null;
let breakStart = null;
let breakSessions = [];
let jobTaskCount = 0;
let jobIdleSeconds = 0;
let jobStartTime = Date.now();
let previousJobId = "None";
let coverageLastPosition = 0;
let coverageTaskCount = 0;
let coverageLastEventKey = "";

// =========================================
// FUNCTION CALCULATE COVERAGE DELTA
// Search: calculateCoverageDelta
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function calculateCoverageDelta(currentPosition, totalTasks) {

    currentPosition = Number(currentPosition) || 0;
    totalTasks = Number(totalTasks) || 0;
    if (currentPosition < 0) {
        currentPosition = 0;
    }
    if (totalTasks > 0 && currentPosition > totalTasks) {
        currentPosition = totalTasks;
    }
    if (coverageLastPosition <= 0) {
        coverageLastPosition = currentPosition;
        debugLog("📌 Coverage baseline established:", currentPosition, "/", totalTasks);
        return 0;
    }
    if (currentPosition <= coverageLastPosition) {
        debugLog("⏸️ No new coverage:", coverageLastPosition, "→", currentPosition);
        return 0;
    }
    const delta = currentPosition - coverageLastPosition;
    coverageLastPosition = currentPosition;
    console.log("📈 Coverage progress:", coverageLastPosition - delta, "→", currentPosition, "| Accepted:", delta);
    return delta;

}
jobTaskCount = 0;
jobIdleSeconds = 0;
jobStartTime = Date.now();
previousJobId = "None";
idleStartTime = null;
idleStartDisplay = "";

// =========================================
// FUNCTION GET INTERVAL KEY
// Search: getIntervalKey
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function getIntervalKey(number) {

    return `interval${number}`;

}

// =========================================
// FUNCTION GET INTERVAL NAME
// Search: getIntervalName
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function getIntervalName(number) {

    if (number === 1) return "1ST";
    if (number === 2) return "2ND";
    if (number === 3) return "3RD";
    return `${number}TH`;

}

// =========================================
// FUNCTION GET INTERVAL FOR TIMESTAMP
// Search: getIntervalForTimestamp
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function getIntervalForTimestamp(timestamp) {

    if (!timestamp) {
        return null;
    }
    const date = new Date(timestamp);
    if (isNaN(date.getTime())) {
        return null;
    }
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Manila",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).formatToParts(date);
    let hour = 0;
    let minute = 0;
    for (const part of parts) {
        if (part.type === "hour") {
            hour = Number(part.value);
        }
        if (part.type === "minute") {
            minute = Number(part.value);
        }
    }
    const totalMinutes = hour * 60 + minute;
    if (totalMinutes >= 15 * 60 && totalMinutes < 17 * 60) {
        return "interval1";
    }
    if (totalMinutes >= 17 * 60 && totalMinutes < 19 * 60) {
        return "interval2";
    }
    if (totalMinutes >= 19 * 60 && totalMinutes <= 21 * 60 + 30) {
        return "interval3";
    }
    return null;

}

// =========================================
// FUNCTION GET PHTIME
// Search: getPHTime
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function getPHTime(timestamp = Date.now()) {

    return new Date(timestamp).toLocaleTimeString("en-US", {
        timeZone: "Asia/Manila",
        hour12: true
    });

}

// =========================================
// FUNCTION START NEW INTERVAL
// Search: startNewInterval
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function startNewInterval(number = 1, startTime = Date.now()) {

    currentIntervalNumber = number;
    currentInterval = {
        number: number,
        started: startTime,
        ended: null,
        tasks: 0,
        jobs: 0,
        confirmation: {
            taskCompleted: 0,
            jobsCompleted: 0
        },
        jobRecords: []
    };
    allTimeTasks = 0;
    totalTaskCompleted = intervalHistory.reduce((sum, interval) => sum + confirmationTotalsFor(interval).taskCompleted, 0);

}

// =========================================
// FUNCTION CURRENT COVERAGE TOTALS
// Search: currentCoverageTotals
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function currentCoverageTotals() {

    const totals = {
        taskCompleted: mode2TaskCompleted,
        jobsCompleted: mode2JobsCompleted,
        emptyAreaConfirmation: mode2EmptyAreaConfirmation,
        emptyAreaNoMatchFound: mode2EmptyAreaNoMatchFound,
        unblurredPerson: mode2UnblurredPerson,
        deletedBoxes: mode2DeletedBoxes,
        skippedTask: mode2SkippedTask
    };
    for (const interval of intervalHistory) {
        for (const key of Object.keys(totals)) {
            totals[key] = Math.max(0, totals[key] - (interval.coverage?.[key] || 0));
        }
    }
    return totals;

}

// =========================================
// FUNCTION CONFIRMATION TOTALS FOR
// Search: confirmationTotalsFor
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function confirmationTotalsFor(interval) {

    if (!interval) return {
        taskCompleted: 0,
        jobsCompleted: 0
    };
    if (interval.confirmation) return interval.confirmation;
    const coverage = interval.coverage || {};
    return {
        taskCompleted: Math.max(0, (interval.tasks || 0) - (coverage.taskCompleted || 0)),
        jobsCompleted: Math.max(0, (interval.jobs || 0) - (coverage.jobsCompleted || 0))
    };

}

// =========================================
// FUNCTION CURRENT CONFIRMATION TOTALS
// Search: currentConfirmationTotals
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function currentConfirmationTotals() {

    if (!currentInterval) return confirmationTotalsFor(null);
    if (!currentInterval.confirmation) {
        currentInterval.confirmation = confirmationTotalsFor(currentInterval);
    }
    return currentInterval.confirmation;

}

// =========================================
// FUNCTION GET INTERVAL COUNTERS
// Search: getIntervalCounters
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function getIntervalCounters() {

    return {
        mode1: currentConfirmationTotals(),
        mode2: currentCoverageTotals()
    };

}

// =========================================
// FUNCTION RESET INTERVAL
// Search: resetInterval
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function resetInterval() {

    const resetTime = Date.now();
    const oldIntervalName = getIntervalName(currentIntervalNumber);
    closeCurrentInterval(resetTime);
    beginNextInterval();
    lastLogTimePH = getPHTime(resetTime);
    saveStats();
    logWithTimestamp(`INTERVAL RESET: ${oldIntervalName} saved; ${getIntervalName(currentIntervalNumber)} started.`);
    broadcastToBrowser('interval_reset');
    scheduleDashboard();

}

// =========================================
// FUNCTION CLOSE CURRENT INTERVAL
// Search: closeCurrentInterval
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function closeCurrentInterval(endTime = Date.now()) {

    if (!currentInterval) return;
    const coverage = currentCoverageTotals();
    if (trackingMode === 2) {
        currentInterval.tasks = coverage.taskCompleted;
        currentInterval.jobs = coverage.jobsCompleted;
    }
    currentInterval.coverage = coverage;
    currentInterval.ended = endTime;
    if (currentInterval.tasks > 0 || currentInterval.jobs > 0 || Object.values(coverage).some(value => value > 0)) {
        intervalHistory.push({
            confirmation: {
                ...currentConfirmationTotals()
            },
            coverage: {
                ...coverage
            },
            number: currentInterval.number,
            started: currentInterval.started,
            ended: currentInterval.ended,
            tasks: currentInterval.tasks,
            jobs: currentInterval.jobs,
            jobRecords: currentInterval.jobRecords || []
        });
    }
    totalTaskCompleted = intervalHistory.reduce((sum, interval) => sum + confirmationTotalsFor(interval).taskCompleted, 0);

}

// =========================================
// FUNCTION BEGIN NEXT INTERVAL
// Search: beginNextInterval
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function beginNextInterval() {

    let nextNumber = currentIntervalNumber + 1;
    if (nextNumber > 3) {
        nextNumber = 3;
    }
    startNewInterval(nextNumber, Date.now());

}

// =========================================
// FUNCTION ADD JOB TO CURRENT INTERVAL
// Search: addJobToCurrentInterval
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function addJobToCurrentInterval(job) {

    if (!currentInterval) {
        startNewInterval(currentIntervalNumber || 1);
    }
    if (trackingMode === 1) {
        currentConfirmationTotals().jobsCompleted += 1;
        currentInterval.jobs += 1;
    }
    currentInterval.jobRecords.push({
        jobId: job.jobId,
        tasks: job.tasks || 0,
        idle: job.idle || 0,
        active: job.active || 0,
        duration: job.duration || 0,
        started: job.started || Date.now(),
        finished: job.finished || Date.now()
    });
    saveStats();

}

// =========================================
// FUNCTION LOAD STATS
// Search: loadStats
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function loadStats() {

    if (!fs.existsSync(statsFile)) return;
    const stats = JSON.parse(fs.readFileSync(statsFile));
    const today = new Date().toISOString().split('T')[0];
    const statsDate = stats.date || null;
    if (statsDate !== null && statsDate !== today) {
        allTimeTasks = stats.allTimeTasks || 0;
        if (stats.completedJobs && stats.completedJobs.length > 0) {
            generateReport(stats).then(success => {
                if (success) {
                    logWithTimestamp("DAILY REPORT GENERATED FOR PREVIOUS DATE: " + statsDate);
                } else {
                    logWithTimestamp("NO DATA TO GENERATE DAILY REPORT FOR PREVIOUS DATE: " + statsDate);
                }
            }).catch(err => {
                console.error("Error generating previous day report:", err);
            });
        }
        totalTaskCompleted = 0;
        totalJobsCompleted = 0;
        totalIdleSeconds = 0;
        totalActiveSeconds = 0;
        lastJobFinished = null;
        completedJobs = [];
        intervalStats = {
            interval1: {
                jobs: [],
                tasks: 0,
                idle: 0,
                active: 0
            },
            interval2: {
                jobs: [],
                tasks: 0,
                idle: 0,
                active: 0
            },
            interval3: {
                jobs: [],
                tasks: 0,
                idle: 0,
                active: 0
            }
        };
        intervalHistory = [];
        startNewInterval(1);
        breakSessions = [];
    } else {
        allTimeTasks = stats.allTimeTasks || 0;
        totalTaskCompleted = stats.totalTaskCompleted || 0;
        totalJobsCompleted = stats.totalJobsCompleted || 0;
        totalIdleSeconds = stats.totalIdleSeconds || 0;
        totalActiveSeconds = stats.totalActiveSeconds || 0;
        lastJobFinished = stats.lastJobFinished || null;
        completedJobs = stats.completedJobs || [];
        intervalHistory = stats.intervalHistory || [];
        currentIntervalNumber = stats.currentIntervalNumber || 1;
        if (stats.currentInterval) {
            currentInterval = stats.currentInterval;
            totalTaskCompleted = intervalHistory.reduce((sum, interval) => sum + confirmationTotalsFor(interval).taskCompleted, 0) + currentConfirmationTotals().taskCompleted;
        } else {
            startNewInterval(1);
        }
    }

}

// =========================================
// FUNCTION COVERAGE DATE
// Search: coverageDate
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function coverageDate(timestamp = Date.now()) {

    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Manila',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(new Date(timestamp));

}
let mode2Date = coverageDate();
let coverageSubmittedTasks = {};

// =========================================
// FUNCTION ENSURE COVERAGE DATE
// Search: ensureCoverageDate
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function ensureCoverageDate() {

    if (mode2Date === coverageDate()) return;
    mode2Date = coverageDate();
    resetCoverageCounters(true);
    saveStats();
    broadcastToBrowser('coverage_daily_reset');

}

// =========================================
// FUNCTION LOAD MODE2 STATS
// Search: loadMode2Stats
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function loadMode2Stats() {

    try {
        if (fs.existsSync(mode2StatsFile)) {
            const raw = fs.readFileSync(mode2StatsFile, "utf8");
            const saved = JSON.parse(raw);
            mode2Date = saved.date || coverageDate(fs.statSync(mode2StatsFile).mtimeMs);
            if (mode2Date !== coverageDate()) {
                ensureCoverageDate();
                return;
            }
            mode2TaskCompleted = Number(saved.mode2TaskCompleted ?? saved.totalTaskCompleted) || 0;
            mode2JobsCompleted = Number(saved.mode2JobsCompleted ?? saved.totalJobsCompleted) || 0;
            mode2DeletedBoxes = Number(saved.mode2DeletedBoxes) || 0;
            mode2EmptyAreaConfirmation = Number(saved.mode2EmptyAreaConfirmation ?? saved.emptyAreaConfirmation) || 0;
            mode2EmptyAreaNoMatchFound = Number(saved.mode2EmptyAreaNoMatchFound ?? saved.emptyAreaNoMatchFound) || 0;
            mode2UnblurredPerson = Number(saved.mode2UnblurredPerson ?? saved.unblurredPerson) || 0;
            mode2SkippedTask = Number(saved.mode2SkippedTask ?? saved.skippedTask) || 0;
            coverageSubmittedTasks = saved.submittedTasks || {};
            syncMode2Stats();
            debugLog("✅ Mode 2 statistics loaded:", mode2Stats);
        } else {
            debugLog("ℹ️ No Mode 2 statistics file found. Creating new storage.");
            syncMode2Stats();
            saveMode2Stats();
        }
    } catch (error) {
        console.error("❌ Failed to load Mode 2 statistics:", error);
        mode2TaskCompleted = 0;
        mode2JobsCompleted = 0;
        mode2DeletedBoxes = 0;
        mode2EmptyAreaConfirmation = 0;
        mode2EmptyAreaNoMatchFound = 0;
        mode2UnblurredPerson = 0;
        mode2SkippedTask = 0;
        syncMode2Stats();
    }

}

// =========================================
// FUNCTION SAVE MODE2 STATS
// Search: saveMode2Stats
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function saveMode2Stats() {

    try {
        syncMode2Stats();
        fs.writeFileSync(mode2StatsFile, JSON.stringify({
            ...mode2Stats,
            date: mode2Date,
            submittedTasks: coverageSubmittedTasks
        }, null, 2), "utf8");
        debugLog("💾 Mode 2 statistics saved.");
    } catch (error) {
        console.error("❌ Failed to save Mode 2 statistics:", error);
    }

}

// =========================================
// FUNCTION RESET COVERAGE COUNTERS
// Search: resetCoverageCounters
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function resetCoverageCounters(fullReset = false) {

    mode2Date = coverageDate();
    mode2TaskCompleted = 0;
    if (fullReset) {
        coverageSubmittedTasks = {};
        mode2JobsCompleted = 0;
        mode2DeletedBoxes = 0;
        mode2EmptyAreaConfirmation = 0;
        mode2EmptyAreaNoMatchFound = 0;
        mode2UnblurredPerson = 0;
        mode2SkippedTask = 0;
    }
    saveMode2Stats();

}

// =========================================
// FUNCTION VALIDATE COVERAGE SUBMISSION
// Search: validateCoverageSubmission
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function validateCoverageSubmission(payload) {

    const values = payload.coverageMetrics;
    return /^JOB_[a-z0-9_]+$/i.test(payload.jobId || '') && Number.isInteger(payload.submittedTaskPosition) && payload.submittedTaskPosition >= 1 && Number.isInteger(payload.totalTasks) && payload.totalTasks >= payload.submittedTaskPosition && values && ['emptyAreaConfirmation', 'emptyAreaNoMatchFound', 'unblurredPerson', 'deletedBoxes'].every(key => Number.isSafeInteger(values[key]) && values[key] >= 0);

}

// =========================================
// FUNCTION APPLY COVERAGE SUBMISSION
// Search: applyCoverageSubmission
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function applyCoverageSubmission(payload) {

    const values = payload.coverageMetrics;
    mode2EmptyAreaConfirmation += values.emptyAreaConfirmation;
    mode2EmptyAreaNoMatchFound += values.emptyAreaNoMatchFound;
    mode2UnblurredPerson += values.unblurredPerson;
    mode2DeletedBoxes += values.deletedBoxes;
    coverageSubmittedTasks[JSON.stringify([payload.jobId, payload.submittedTaskPosition])] = true;

}

// =========================================
// FUNCTION RESET ALL COUNTERS
// Search: resetAllCounters
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function resetAllCounters() {

    allTimeTasks = 0;
    totalTaskCompleted = 0;
    totalJobsCompleted = 0;
    totalIdleSeconds = 0;
    totalActiveSeconds = 0;
    completedJobs = [];
    intervalHistory = [];
    intervalStats = Object.fromEntries([1, 2, 3].map(number => ['interval' + number, {
        jobs: [],
        tasks: 0,
        idle: 0,
        active: 0
    }]));
    startNewInterval(1);
    if (breakTimer !== null) clearInterval(breakTimer);
    breakTimer = null;
    onBreak = false;
    breakStart = null;
    breakSessions = [];
    idleStartTime = null;
    idleStartDisplay = '';
    idleReason = 'Unknown';
    lastStatusPH = 'ACTIVE';
    currentJobId = 'No Active Job Detected';
    currentJobUrl = '';
    currentJobDescription = '';
    pendingJobId = '';
    pendingJobUrl = '';
    pendingJobDescription = '';
    previousJobId = 'None';
    lastJobFinished = null;
    jobConfirmed = false;
    lastTotalTasksDone = 0;
    jobTaskCount = 0;
    jobIdleSeconds = 0;
    jobStartedAt = Date.now();
    jobStartTime = jobStartedAt;
    coverageLastPosition = 0;
    coverageTaskCount = 0;
    coverageLastEventKey = '';
    for (const jobId of Object.keys(jobTasks)) delete jobTasks[jobId];
    resetCoverageCounters(true);
    saveStats();
    lastLogTimePH = 'ALL WIPED CLEAN';
    logWithTimestamp('RESET ALL: Counters and interval history cleared; tracking mode preserved.');
    broadcastToBrowser('reset_all_counters');
    scheduleDashboard();

}

// =========================================
// FUNCTION SAVE STATS
// Search: saveStats
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function saveStats() {

    const today = new Date().toISOString().split('T')[0];
    fs.writeFileSync(statsFile, JSON.stringify({
        date: today,
        allTimeTasks,
        totalTaskCompleted,
        totalJobsCompleted,
        trackingMode,
        mode2: {
            taskCompleted: mode2TaskCompleted,
            jobsCompleted: mode2JobsCompleted,
            deletedBoxes: mode2DeletedBoxes,
            emptyAreaConfirmation: mode2EmptyAreaConfirmation,
            emptyAreaNoMatchFound: mode2EmptyAreaNoMatchFound,
            unblurredPerson: mode2UnblurredPerson,
            skippedTask: mode2SkippedTask
        },
        totalIdleSeconds,
        totalActiveSeconds,
        lastJobFinished,
        completedJobs,
        intervalHistory,
        currentIntervalNumber,
        currentInterval
    }, null, 2));

}

// =========================================
// FUNCTION GET TODAY LOG FILE
// Search: getTodayLogFile
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function getTodayLogFile() {

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return path.join(logsFolder, `${year}-${month}-${day}.txt`);

}

// =========================================
// FUNCTION LOG WITH TIMESTAMP
// Search: logWithTimestamp
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function logWithTimestamp(message) {

    const optionsPH = {
        timeZone: 'Asia/Manila',
        hour12: true,
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const pht = new Date().toLocaleString('en-US', optionsPH);
    fs.appendFileSync(getTodayLogFile(), `[${currentJobId} | ${pht}] ${message}\n`);
    return pht;

}

// =========================================
// FUNCTION BROADCAST TO BROWSER
// Search: broadcastToBrowser
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function broadcastToBrowser(messageType) {

    const dataPayload = JSON.stringify({
        action: messageType,
        trackingMode,
        intervalCounters: getIntervalCounters(),
        mode2: {
            taskCompleted: mode2TaskCompleted,
            jobsCompleted: mode2JobsCompleted,
            deletedBoxes: mode2DeletedBoxes,
            emptyAreaConfirmation: mode2EmptyAreaConfirmation,
            emptyAreaNoMatchFound: mode2EmptyAreaNoMatchFound,
            unblurredPerson: mode2UnblurredPerson,
            skippedTask: mode2SkippedTask
        },
        allTimeTasks,
        totalTaskCompleted,
        totalJobsCompleted,
        currentJobId: currentJobId === "No Active Job Detected" ? "None" : currentJobId,
        agentStatus: lastStatusPH,
        currentInterval: currentInterval ? {
            number: currentInterval.number,
            tasks: currentInterval.tasks,
            jobs: currentInterval.jobs,
            started: currentInterval.started,
            ended: currentInterval.ended
        } : null
    });
    clients.forEach(client => {
        try {
            client.write(`data: ${dataPayload}\n\n`);
        } catch (err) {
            console.error("❌ SSE broadcast error:", err);
        }
    });

}
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// =========================================
// FUNCTION SET TRACKER MODE
// Search: setTrackerMode
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function setTrackerMode(mode) {

    const selected = Number(mode);
    if (selected !== 1 && selected !== 2) return false;
    trackingMode = selected;
    return true;

}

// =========================================
// FUNCTION SELECT TRACKER MODE
// Search: selectTrackerMode
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
async function selectTrackerMode() {

    if (trackingMode === 1 || trackingMode === 2) return true;
    console.clear();
    console.log("TASK TRACKER | Select mode");
    console.log("[1] Confirmation  [2] Coverage  [3] Exit");
    while (true) {
        const answer = await new Promise(resolve => rl.question("Mode: ", resolve));
        if (answer.trim() === "3") {
            rl.close();
            process.exit(0);
        }
        if (setTrackerMode(answer.trim())) return true;
        console.log("Please enter 1, 2, or 3.");
    }

}

// =========================================
// FUNCTION GET TAMPERMONKEY SCRIPT INFO
// Search: getTampermonkeyScriptInfo
// Ver 0.0.6 Alpha || 2026-09-07 || JBallados
// =========================================
function getTampermonkeyScriptInfo() {

    if (!fs.existsSync(tampermonkeyScriptFile)) {
        return { exists: false, valid: false, name: null, version: null };
    }
    const source = fs.readFileSync(tampermonkeyScriptFile, "utf8");
    const nameMatch = source.match(/^\/\/\s*@name\s+(.+)$/m);
    const versionMatch = source.match(/^\/\/\s*@version\s+(.+)$/m);
    return {
        exists: true,
        valid: source.includes("// ==UserScript==") && source.includes("// ==/UserScript=="),
        name: nameMatch ? nameMatch[1].trim() : null,
        version: versionMatch ? versionMatch[1].trim() : null
    };

}

// =========================================
// FUNCTION OPEN TAMPERMONKEY UPDATER
// Search: openTampermonkeyUpdater
// Ver 0.0.6 Alpha || 2026-09-07 || JBallados
// =========================================
function openTampermonkeyUpdater() {

    const info = getTampermonkeyScriptInfo();
    if (!info.exists || !info.valid) {
        console.log("Tampermonkey userscript source is missing or invalid.");
        console.log("Expected: " + tampermonkeyScriptFile);
        return false;
    }
    const updaterUrl = "http://localhost:9000/tampermonkey.user.js";
    let command;
    if (process.platform === "win32") {
        command = 'start "" "' + updaterUrl + '"';
    } else if (process.platform === "darwin") {
        command = 'open "' + updaterUrl + '"';
    } else {
        command = 'xdg-open "' + updaterUrl + '"';
    }
    console.log("Opening Tampermonkey userscript...");
    console.log("Script : " + (info.name || "Unknown"));
    console.log("Version: " + (info.version || "Unknown"));
    exec(command, error => {
        if (error) {
            console.error("Could not open browser automatically:", error.message);
            console.log("Open manually: " + updaterUrl);
        }
    });
    return true;

}

// =========================================
// FUNCTION SERVE TAMPERMONKEY SCRIPT
// Search: serveTampermonkeyScript
// Ver 0.0.6 Alpha || 2026-09-07 || JBallados
// =========================================
function serveTampermonkeyScript(res) {

    const info = getTampermonkeyScriptInfo();
    if (!info.exists) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Tampermonkey source file not found.");
        return;
    }
    if (!info.valid) {
        res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Tampermonkey source file is not a valid userscript.");
        return;
    }
    res.writeHead(200, {
        "Content-Type": "application/javascript; charset=utf-8",
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "Content-Disposition": 'inline; filename="TamperMonkey-Mods.user.js"'
    });
    res.end(fs.readFileSync(tampermonkeyScriptFile, "utf8"));

}

// =========================================
// FUNCTION SERVE TAMPERMONKEY METADATA
// Search: serveTampermonkeyMetadata
// Ver 0.0.6 Alpha || 2026-09-07 || JBallados
// =========================================
function serveTampermonkeyMetadata(res) {

    const info = getTampermonkeyScriptInfo();
    if (!info.exists) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Tampermonkey source file not found.");
        return;
    }
    if (!info.valid) {
        res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Tampermonkey source file is not a valid userscript.");
        return;
    }
    const source = fs.readFileSync(tampermonkeyScriptFile, "utf8");
    const metadataMatch = source.match(/\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/);
    if (!metadataMatch) {
        res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Tampermonkey metadata block could not be extracted.");
        return;
    }
    res.writeHead(200, {
        "Content-Type": "application/javascript; charset=utf-8",
        "Cache-Control": "no-store, no-cache, must-revalidate"
    });
    res.end(metadataMatch[0] + "\n");

}

let dashboardRenderPending = false;
let lastDashboardSnapshot = null;

// =========================================
// FUNCTION SCHEDULE DASHBOARD
// Search: scheduleDashboard
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function scheduleDashboard() {

    if (!trackerStartupComplete || dashboardRenderPending) return;
    dashboardRenderPending = true;
    setTimeout(() => {
        dashboardRenderPending = false;
        drawDashboard();
    }, 100);

}

// =========================================
// FUNCTION DASHBOARD TEXT
// Search: dashboardText
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// Ver 0.0.6 Alpha || 2026-09-07 || JBallados
// =========================================
function dashboardText() {

    if (trackingMode !== 1 && trackingMode !== 2) return "";
    const coverageMode = trackingMode === 2;
    const lines = [`TASK TRACKER | Mode ${trackingMode}: ${coverageMode ? "Coverage" : "Confirmation"}`, `Job: ${currentJobId || "No active job"} | Status: ${lastStatusPH}`, `Last update (PH): ${lastLogTimePH} | Last job: ${lastJobFinished || "None"}`, `Total: ${coverageMode ? mode2TaskCompleted : totalTaskCompleted} tasks | ${coverageMode ? mode2JobsCompleted : totalJobsCompleted} jobs`, "", "INTERVALS"];
    const intervals = [...intervalHistory];
    if (currentInterval) intervals.push(currentInterval);
    for (const interval of intervals) {
        const isCurrent = interval === currentInterval;
        const totals = coverageMode ? isCurrent ? currentCoverageTotals() : interval.coverage || {} : isCurrent ? currentConfirmationTotals() : confirmationTotalsFor(interval);
        lines.push(`${getIntervalName(interval.number)} | ${getPHTime(interval.started)} - ${isCurrent ? "CURRENT" : getPHTime(interval.ended)} | Tasks: ${totals.taskCompleted ?? "N/A"} | Jobs: ${totals.jobsCompleted ?? "N/A"}`);
        if (coverageMode) {
            lines.push(`  Empty confirmed: ${totals.emptyAreaConfirmation ?? "N/A"} | No match: ${totals.emptyAreaNoMatchFound ?? "N/A"}`);
            lines.push(`  Unblurred: ${totals.unblurredPerson ?? "N/A"} | Deleted: ${totals.deletedBoxes ?? "N/A"} | Skipped: ${totals.skippedTask ?? "N/A"}`);
        }
    }
    lines.push("", `[1] Reset interval  [2] Reset all  [3] Restart  [${coverageMode ? "4] Confirmation" : "5] Coverage"}`, "Commands: report | break | resume | update tampermonkey");
    return lines.join("\n");

}

// =========================================
// FUNCTION DRAW DASHBOARD
// Search: drawDashboard
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function drawDashboard() {

    const output = dashboardText();
    if (!output || output === lastDashboardSnapshot) return;
    lastDashboardSnapshot = output;
    console.clear();
    console.log(output);

}

// =========================================
// FUNCTION FORMAT DURATION
// Search: formatDuration
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function formatDuration(seconds) {

    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor(seconds % 3600 / 60);
    const secs = seconds % 60;
    if (hrs > 0) {
        return `${hrs}h ${mins}m ${secs}s`;
    }
    return `${mins}m ${secs}s`;

}
rl.on('line', input => {
    if (!trackerStartupComplete) return;
    const command = input.trim().toLowerCase();
    if (command === "4") {
        setTrackerMode(1);
        console.log("");
        debugLog("✅ TRACKING MODE CHANGED TO MODE 1 — CONFIRMATION");
        console.log("");
        saveStats();
        broadcastToBrowser("tracking_mode_changed");
        scheduleDashboard();
        return;
    } else if (command === "5") {
        setTrackerMode(2);
        console.log("");
        debugLog("✅ TRACKING MODE CHANGED TO MODE 2 — COVERAGE");
        console.log("");
        saveStats();
        broadcastToBrowser("tracking_mode_changed");
        scheduleDashboard();
        return;
    } else if (command === "break") {
        startBreak();
        return;
    } else if (command === "resume") {
        endBreak();
        return;
    } else if (command === "update tampermonkey") {
        openTampermonkeyUpdater();
        return;
    } else if (command === "report") {
        generateReport().then(success => {
            console.log(success ? `Report saved in: ${reportsFolder}` : "No completed jobs to report yet.");
        }).catch(error => {
            console.error("Failed to generate report:", error.message);
        });
        return;
    } else if (command === "1" || command === "reset") {
        resetInterval();
    } else if (command === "2" || command === "reset all") {
        resetAllCounters();
    } else if (command === "3" || command === "restart") {
        console.log("Restarting server...");
        logWithTimestamp("COMMAND: Restart Initiated Restarting Tracker");
        process.exit(0);
    } else if (command === "") {
        return;
    } else {
        lastLogTimePH = "INVALID CMD";
        logWithTimestamp(`ERROR: Unknown command received: "${input}"`);
        scheduleDashboard();
        console.log("");
        console.log("❌ UNKNOWN COMMAND: \"" + input + "\"");
        console.log("Available commands: 'break', 'resume', 'reset', 'reset all', 'report', 'restart', 'update tampermonkey'");
        console.log("");
    }
});
const server = http.createServer((req, res) => {
    if (trackerStartupComplete) ensureCoverageDate();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }
    if (req.method === 'GET' && req.url === '/stats') {
        res.writeHead(200, {
            'Content-Type': 'application/json'
        });
        res.end(JSON.stringify({
            allTimeTasks,
            totalTaskCompleted,
            totalJobsCompleted,
            trackingMode,
            intervalCounters: getIntervalCounters(),
            mode2: {
                taskCompleted: mode2TaskCompleted,
                jobsCompleted: mode2JobsCompleted,
                deletedBoxes: mode2DeletedBoxes,
                emptyAreaConfirmation: mode2EmptyAreaConfirmation,
                emptyAreaNoMatchFound: mode2EmptyAreaNoMatchFound,
                unblurredPerson: mode2UnblurredPerson,
                skippedTask: mode2SkippedTask
            },
            currentJobId: currentJobId === "No Active Job Detected" ? "None" : currentJobId,
            agentStatus: lastStatusPH,
            currentInterval: currentInterval ? {
                number: currentInterval.number,
                tasks: currentInterval.tasks,
                jobs: currentInterval.jobs,
                started: currentInterval.started,
                ended: currentInterval.ended
            } : null
        }));
        return;
    }
    if (req.method === 'GET' && req.url === '/tampermonkey.meta.js') {
        serveTampermonkeyMetadata(res);
        return;
    }
    if (req.method === 'GET' && req.url === '/tampermonkey.user.js') {
        serveTampermonkeyScript(res);
        return;
    }
    if (req.method === 'GET' && req.url === '/events') {
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive'
        });
        clients.push(res);
        req.on('close', () => {
            clients = clients.filter(client => client !== res);
        });
        return;
    }
    if (req.method === 'GET' && (req.url === '/dashboard' || req.url.startsWith('/dashboard/'))) {
        const requested = req.url === '/dashboard' ? '/dashboard/index.html' : req.url;
        const filePath = path.join(__dirname, requested.replace(/^\//, ''));
        if (fs.existsSync(filePath)) {
            const ext = path.extname(filePath).toLowerCase();
            const contentType = ext === '.css' ? 'text/css' : 'text/html';
            res.writeHead(200, {
                'Content-Type': contentType
            });
            res.end(fs.readFileSync(filePath, 'utf8'));
            return;
        } else {
            res.writeHead(404, {
                'Content-Type': 'text/plain'
            });
            res.end('Not found');
            return;
        }
    }
    if (req.method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            try {
                const payload = JSON.parse(body);
                if (payload.action === 'break') {
                    startBreak();
                    res.writeHead(200, {
                        'Content-Type': 'application/json'
                    });
                    return res.end(JSON.stringify({
                        status: 'BREAK',
                        totalTaskCompleted,
                        totalJobsCompleted,
                        currentJobId
                    }));
                }
                if (payload.action === 'resume') {
                    endBreak();
                    res.writeHead(200, {
                        'Content-Type': 'application/json'
                    });
                    return res.end(JSON.stringify({
                        status: 'ACTIVE',
                        totalTaskCompleted,
                        totalJobsCompleted,
                        currentJobId
                    }));
                }
                if (payload.action === 'reset' || payload.action === 'reset_all') {
                    if (payload.action === 'reset') resetInterval();else resetAllCounters();
                    res.writeHead(200, {
                        'Content-Type': 'application/json'
                    });
                    return res.end(JSON.stringify({
                        status: payload.action === 'reset' ? 'RESET' : 'RESET_ALL',
                        totalTaskCompleted,
                        totalJobsCompleted,
                        allTimeTasks,
                        currentInterval,
                        trackingMode,
                        intervalCounters: getIntervalCounters()
                    }));
                }
                if (payload.action === 'report') {
                    generateReport().then(success => {
                        res.writeHead(200, {
                            'Content-Type': 'application/json'
                        });
                        res.end(JSON.stringify({
                            success
                        }));
                    }).catch(err => {
                        console.error(err);
                        res.writeHead(500, {
                            'Content-Type': 'application/json'
                        });
                        res.end(JSON.stringify({
                            success: false,
                            error: String(err)
                        }));
                    });
                    return;
                }
                if (payload.action === 'coverage_empty_area') {
                    res.writeHead(409, {
                        'Content-Type': 'application/json'
                    });
                    return res.end(JSON.stringify({
                        success: false,
                        error: 'Update userscript: metrics are counted on Submit.'
                    }));
                }
                if (payload.action === 'click_submit' && trackingMode === 2) {
                    if (!validateCoverageSubmission(payload)) {
                        res.writeHead(400, {
                            'Content-Type': 'application/json'
                        });
                        return res.end(JSON.stringify({
                            success: false,
                            error: 'Missing or invalid coverage snapshot.'
                        }));
                    }
                    const key = JSON.stringify([payload.jobId, payload.submittedTaskPosition]);
                    if (coverageSubmittedTasks[key]) {
                        res.writeHead(200, {
                            'Content-Type': 'application/json'
                        });
                        return res.end(JSON.stringify({
                            success: true,
                            duplicate: true
                        }));
                    }
                    payload.isJobFinished = payload.submittedTaskPosition === payload.totalTasks;
                }
                if (payload.jobId && payload.jobId !== currentJobId) {
                    if (currentJobId !== "No Jobs Detected") {
                        previousJobId = currentJobId;
                        if (jobTaskCount > 0) {
                            writeJobSummary();
                        }
                    }
                    currentJobId = payload.jobId;
                    jobTaskCount = 0;
                    jobIdleSeconds = 0;
                    jobStartTime = Date.now();
                    coverageLastPosition = 0;
                    coverageTaskCount = 0;
                    coverageLastEventKey = "";
                }
                if (payload.action === "coverage_skip") {
                    if (trackingMode === 2) {
                        mode2SkippedTask++;
                        syncMode2Stats();
                        saveMode2Stats();
                        saveStats();
                        broadcastToBrowser('coverage_skip');
                        scheduleDashboard();
                    }
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "SKIP_RECORDED",
                        intervalCounters: getIntervalCounters(),
                        mode2: {
                            skippedTask: mode2SkippedTask
                        }
                    }));
                }
                if (payload.action === "click_submit") {
                    const requestId = payload.requestId;
                    if (!requestId) {
                        console.warn("⚠️ CLICK_SUBMIT received without requestId");
                    } else {
                        cleanupProcessedSubmitRequests();
                        if (processedSubmitRequests.has(requestId)) {
                            console.warn("⏳ Duplicate submit request ignored:", requestId);
                            res.writeHead(200, {
                                'Content-Type': 'application/json'
                            });
                            return res.end(JSON.stringify({
                                success: true,
                                duplicate: true,
                                requestId: requestId,
                                message: "Duplicate submit ignored"
                            }));
                        }
                        processedSubmitRequests.set(requestId, Date.now());
                    }
                    console.log(`📥 CLICK_SUBMIT RECEIVED | Job: ${payload.jobId || "NONE"}`);
                    if (!jobConfirmed) {
                        currentJobId = pendingJobId || payload.jobId || currentJobId || "No Active Job Detected";
                        currentJobUrl = pendingJobUrl || payload.jobUrl || "";
                        currentJobDescription = pendingJobDescription || payload.jobDescription || "";
                        jobConfirmed = true;
                        logWithTimestamp("Started Job: " + currentJobId);
                    }
                    let acceptedTaskCount = 0;
                    if (trackingMode === 1) {
                        acceptedTaskCount = 1;
                        jobTaskCount += 1;
                    } else if (trackingMode === 2) {
                        acceptedTaskCount = 1;
                        applyCoverageSubmission(payload);
                        mode2TaskCompleted++;
                        syncMode2Stats();
                        saveMode2Stats();
                        jobTaskCount++;
                        console.log("📦 MODE 2 TASK ACCEPTED | Personal +1");
                        console.log("📊 Mode 2 Task Total:", mode2TaskCompleted);
                    }
                    if (!currentInterval) {
                        startNewInterval(currentIntervalNumber || 1);
                    }
                    if (acceptedTaskCount > 0) {
                        if (trackingMode === 1) {
                            currentConfirmationTotals().taskCompleted += acceptedTaskCount;
                            currentInterval.tasks += acceptedTaskCount;
                            allTimeTasks = currentInterval.tasks;
                            totalTaskCompleted = intervalHistory.reduce((sum, interval) => sum + confirmationTotalsFor(interval).taskCompleted, 0) + currentConfirmationTotals().taskCompleted;
                        }
                        if (trackingMode === 2) {
                            currentInterval.tasks = currentCoverageTotals().taskCompleted;
                            allTimeTasks = currentInterval.tasks;
                        }
                    }
                    if (payload.isJobFinished) {
                        if (trackingMode === 1) {
                            totalJobsCompleted++;
                        } else if (trackingMode === 2) {
                            mode2JobsCompleted++;
                            currentInterval.jobs = currentCoverageTotals().jobsCompleted;
                            syncMode2Stats();
                            saveMode2Stats();
                        }
                    }
                    lastTotalTasksDone++;
                    lastLogTimePH = logWithTimestamp(`TASK ACCEPTED | ` + `Mode: ${trackingMode === 1 ? "CONFIRMATION" : "COVERAGE"} | ` + `Accepted: ${acceptedTaskCount} | ` + `Mode Total: ${trackingMode === 1 ? totalTaskCompleted : mode2TaskCompleted} | ` + (trackingMode === 1 ? `Interval ${currentInterval.number}: ${currentInterval.tasks} | ` : `Coverage Total: ${mode2TaskCompleted} | `) + `Job: ${currentJobId} | ` + `Finished: ${payload.isJobFinished}`);
                    saveStats();
                    scheduleDashboard();
                    if (payload.isJobFinished) {
                        writeJobSummary();
                        jobConfirmed = false;
                        currentJobId = "No Active Job Detected";
                        jobTaskCount = 0;
                        jobIdleSeconds = 0;
                        jobStartTime = Date.now();
                        coverageLastPosition = 0;
                        coverageTaskCount = 0;
                        coverageLastEventKey = "";
                    }
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "TASK_ACCEPTED",
                        allTimeTasks,
                        totalTaskCompleted,
                        totalJobsCompleted,
                        trackingMode,
                        intervalCounters: getIntervalCounters(),
                        mode2: {
                            taskCompleted: mode2TaskCompleted,
                            jobsCompleted: mode2JobsCompleted,
                            deletedBoxes: mode2DeletedBoxes,
                            emptyAreaConfirmation: mode2EmptyAreaConfirmation,
                            emptyAreaNoMatchFound: mode2EmptyAreaNoMatchFound,
                            unblurredPerson: mode2UnblurredPerson,
                            skippedTask: mode2SkippedTask
                        },
                        currentJobId: currentJobId === "No Active Job Detected" ? "None" : currentJobId,
                        agentStatus: lastStatusPH,
                        currentInterval: currentInterval ? {
                            number: currentInterval.number,
                            tasks: currentInterval.tasks,
                            jobs: currentInterval.jobs,
                            started: currentInterval.started,
                            ended: currentInterval.ended
                        } : null
                    }));
                }
                if (payload.action === "job_changed") {
                    if (jobConfirmed && jobTaskCount > 0) {
                        writeJobSummary();
                    }
                    pendingJobId = payload.newJobId;
                    pendingJobUrl = payload.newUrl;
                    pendingJobDescription = payload.newDescription;
                    jobConfirmed = false;
                    jobTaskCount = 0;
                    jobIdleSeconds = 0;
                    jobStartTime = Date.now();
                    return res.end(JSON.stringify({
                        status: "WAITING_CONFIRMATION"
                    }));
                }
                if (payload.action === "idle_alert") {
                    if (onBreak) {
                        return res.end(JSON.stringify({
                            status: "BREAK"
                        }));
                    } else if (lastStatusPH !== "IDLE") {
                        lastStatusPH = "IDLE";
                        idleStartTime = Date.now();
                        idleStartDisplay = new Date().toLocaleTimeString("en-US", {
                            timeZone: "Asia/Manila",
                            hour12: true
                        });
                        logWithTimestamp(`IDLE STARTED: ${idleStartDisplay}`);
                        lastLogTimePH = idleStartDisplay;
                        scheduleDashboard();
                    }
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "IDLE"
                    }));
                } else if (payload.action === "active_alert") {
                    logWithTimestamp("ACTIVE ALERT RECEIVED");
                    if (onBreak) {
                        return res.end(JSON.stringify({
                            status: "BREAK"
                        }));
                    } else if (lastStatusPH === "IDLE" && idleStartTime) {
                        const idleEnd = Date.now();
                        const idleSeconds = Math.floor((idleEnd - idleStartTime) / 1000);
                        totalIdleSeconds += idleSeconds;
                        jobIdleSeconds += idleSeconds;
                        const idleEndDisplay = new Date().toLocaleTimeString("en-US", {
                            timeZone: "Asia/Manila",
                            hour12: true
                        });
                        const now = new Date();
                        const entry = `
	=========================================================
	IDLE SESSION
	Date          : ${now.toLocaleDateString("en-US")}
	Job ID        : ${currentJobId}
	Idle Started  : ${idleStartDisplay}
	Idle Ended    : ${idleEndDisplay}
	Duration      : ${formatDuration(idleSeconds)}
	=========================================================
							`;
                        fs.appendFileSync(getTodayLogFile(), entry);
                        idleSessions.push({
                            jobId: currentJobId,
                            started: idleStartDisplay,
                            ended: idleEndDisplay,
                            duration: idleSeconds
                        });
                        idleStartTime = null;
                        idleStartDisplay = "";
                        lastStatusPH = "ACTIVE";
                        lastLogTimePH = idleEndDisplay;
                        scheduleDashboard();
                    }
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "ACTIVE"
                    }));
                }
                if (payload.action === "window_blur") {
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "WINDOW_BLUR"
                    }));
                }
                if (payload.action === "window_focus") {
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "WINDOW_FOCUS"
                    }));
                }
                if (payload.action === "tab_hidden") {
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "TAB_HIDDEN"
                    }));
                }
                if (payload.action === "tab_visible") {
                    res.writeHead(200, {
                        "Content-Type": "application/json"
                    });
                    return res.end(JSON.stringify({
                        status: "TAB_VISIBLE"
                    }));
                }
                res.writeHead(400, {
                    "Content-Type": "application/json"
                });
                res.end(JSON.stringify({
                    error: "Unknown action"
                }));
            } catch (err) {
                console.error(err);
                logWithTimestamp("Error occurred while processing request");
                res.writeHead(400, {
                    "Content-Type": "application/json"
                });
                res.end(JSON.stringify({
                    error: "Invalid JSON"
                }));
            }
        });
    }
});

// =========================================
// FUNCTION START TRACKER
// Search: startTracker
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// Ver 0.0.6 Alpha || 2026-09-07 || JBallados
// =========================================
function startTracker() {

    server.listen(9000, async () => {
        if (fs.existsSync(installTampermonkeyMarker)) {
            try {
                fs.unlinkSync(installTampermonkeyMarker);
            } catch {}
            setTimeout(openTampermonkeyUpdater, 1000);
        }
        const modeSelected = await selectTrackerMode();
        if (!modeSelected) return;
        loadStats();
        loadMode2Stats();
        setInterval(ensureCoverageDate, 1000);

        trackerStartupComplete = true;
        drawDashboard();
    });

}
startTracker();

// =========================================
// FUNCTION START BREAK
// Search: startBreak
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function startBreak() {

    if (onBreak) return;
    onBreak = true;
    breakStart = Date.now();
    idleStartDisplay = new Date().toLocaleTimeString('en-US', {
        timeZone: 'Asia/Manila',
        hour12: true
    });
    lastStatusPH = "BREAK";
    logWithTimestamp("BREAK STARTED");
    scheduleDashboard();
    breakSessions.push({
        started: Date.now(),
        startedDisplay: idleStartDisplay,
        ended: null,
        duration: null
    });
    breakTimer = setTimeout(() => {
        endBreak();
    }, SHIFT.breakMinutes * 60 * 1000);

}

// =========================================
// FUNCTION END BREAK
// Search: endBreak
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function endBreak() {

    if (!onBreak) return;
    clearTimeout(breakTimer);
    const seconds = Math.floor((Date.now() - breakStart) / 1000);
    logWithTimestamp("BREAK ENDED (" + formatDuration(seconds) + ")");
    totalIdleSeconds += seconds;
    if (jobConfirmed) {
        jobIdleSeconds += seconds;
        idleSessions.push({
            jobId: currentJobId,
            started: idleStartDisplay || 'BREAK START',
            ended: new Date().toLocaleTimeString('en-US', {
                timeZone: 'Asia/Manila',
                hour12: true
            }),
            duration: seconds
        });
    }
    for (let i = breakSessions.length - 1; i >= 0; i--) {
        if (!breakSessions[i].ended) {
            breakSessions[i].ended = Date.now();
            breakSessions[i].endedDisplay = new Date().toLocaleTimeString('en-US', {
                timeZone: 'Asia/Manila',
                hour12: true
            });
            breakSessions[i].duration = seconds;
            break;
        }
    }
    onBreak = false;
    breakStart = null;
    lastStatusPH = "ACTIVE";
    scheduleDashboard();

}

// =========================================
// FUNCTION WRITE JOB SUMMARY
// Search: writeJobSummary
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function writeJobSummary() {

    if (!currentJobId) return;
    const jobEndTime = Date.now();
    const durationSeconds = Math.floor((jobEndTime - jobStartTime) / 1000);
    const activeSeconds = durationSeconds - jobIdleSeconds;
    totalActiveSeconds += activeSeconds;
    if (jobTaskCount === 0 && durationSeconds < 10) {
        return;
    }
    lastJobFinished = new Date().toLocaleTimeString('en-US', {
        timeZone: 'Asia/Manila',
        hour12: true
    });
    completedJobs.push({
        jobId: currentJobId,
        tasks: jobTaskCount,
        duration: durationSeconds,
        idle: jobIdleSeconds,
        active: activeSeconds,
        started: jobStartTime,
        finished: Date.now()
    });
    const finishedTime = Date.now();
    const jobRecord = {
        jobId: currentJobId,
        tasks: jobTaskCount,
        idle: jobIdleSeconds,
        active: activeSeconds,
        duration: durationSeconds,
        started: jobStartTime,
        finished: finishedTime
    };
    addJobToCurrentInterval(jobRecord);
    const intervalKey = getIntervalKey(currentIntervalNumber);
    if (intervalStats[intervalKey]) {
        intervalStats[intervalKey].jobs.push(jobRecord);
        intervalStats[intervalKey].tasks += jobTaskCount;
        intervalStats[intervalKey].idle += jobIdleSeconds;
        intervalStats[intervalKey].active += activeSeconds;
    }
    console.log("Completed Jobs:", completedJobs.length);
    logWithTimestamp("Completed Jobs: " + completedJobs.length);
    saveStats();
    const efficiency = durationSeconds > 0 ? Math.round(activeSeconds / durationSeconds * 100) : 100;
    const summary = `
	==================================================
	JOB SUMMARY
	==================================================

	Job ID        : ${currentJobId}

	Started       : ${new Date(jobStartTime).toLocaleTimeString("en-US", {
        timeZone: "Asia/Manila",
        hour12: true
    })}

	Finished      : ${new Date().toLocaleTimeString()}

	Duration      : ${formatDuration(durationSeconds)}

	Tasks         : ${jobTaskCount}

	Idle Time     : ${formatDuration(jobIdleSeconds)}

	Active Time   : ${formatDuration(activeSeconds)}

	Efficiency    : ${efficiency}%

	==================================================

	`;
    fs.appendFileSync(getTodayLogFile(), summary);

}

// =========================================
// FUNCTION FORMAT HOUR
// Search: formatHour
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function formatHour(hour, minute = 0) {

    const h = hour % 12 === 0 ? 12 : hour % 12;
    const mm = String(minute).padStart(2, '0');
    const suffix = hour >= 12 ? 'PM' : 'AM';
    return `${h}:${mm} ${suffix}`;

}

// =========================================
// FUNCTION POPULATE INTERVAL SHEET
// Search: populateIntervalSheet
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function populateIntervalSheet(sheet, interval, intervalConfig, reportDate, intervalName) {

    sheet.addRow([`Report Date`, reportDate]);
    const startMin = intervalConfig.startMinute || 0;
    const endMin = intervalConfig.endMinute || 0;
    const startLabel = formatHour(intervalConfig.startHour, startMin);
    const endLabel = formatHour(intervalConfig.endHour || intervalConfig.startHour + 2, endMin);
    sheet.addRow([`Interval`, `${intervalName} (${startLabel} - ${endLabel})`]);
    sheet.addRow([`Break Minutes`, SHIFT.breakMinutes + ' mins']);
    sheet.addRow([]);
    sheet.addRow(["Job ID", "Tasks", "Started", "Finished", "Idle", "Active", "Duration", "Efficiency"]);
    sheet.getRow(sheet.lastRow.number).font = {
        bold: true
    };
    interval.jobs.forEach(job => {
        const started = job.started ? new Date(job.started).toLocaleTimeString('en-US', {
            hour12: true
        }) : '';
        const finished = job.finished ? new Date(job.finished).toLocaleTimeString('en-US', {
            hour12: true
        }) : '';
        const eff = job.duration > 0 ? Math.round(job.active / job.duration * 100) : 100;
        sheet.addRow([job.jobId, job.tasks, started, finished, formatDuration(job.idle), formatDuration(job.active), formatDuration(job.duration), eff + "%"]);
    });
    const totals = interval.jobs.reduce((acc, job) => {
        acc.tasks += job.tasks || 0;
        acc.idle += job.idle || 0;
        acc.active += job.active || 0;
        acc.duration += job.duration || 0;
        return acc;
    }, {
        tasks: 0,
        idle: 0,
        active: 0,
        duration: 0
    });
    sheet.addRow([]);
    const totalEff = totals.duration > 0 ? Math.round(totals.active / totals.duration * 100) : 100;
    sheet.addRow(['Totals', totals.tasks, '', '', formatDuration(totals.idle), formatDuration(totals.active), formatDuration(totals.duration), totalEff + "%"]);
    sheet.getRow(sheet.lastRow.number).font = {
        bold: true
    };

}

// =========================================
// FUNCTION GENERATE REPORT
// Search: generateReport
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
async function generateReport(overrideStats) {

    const usedCompleted = overrideStats ? overrideStats.completedJobs || [] : completedJobs;
    const usedTotalTasks = overrideStats ? overrideStats.totalTaskCompleted || 0 : totalTaskCompleted;
    const usedIdle = overrideStats ? overrideStats.totalIdleSeconds || 0 : totalIdleSeconds;
    const usedActive = overrideStats ? overrideStats.totalActiveSeconds || 0 : totalActiveSeconds;
    const usedBreaks = overrideStats ? overrideStats.breakSessions || [] : breakSessions;
    const usedLastFinished = overrideStats ? overrideStats.lastJobFinished || null : lastJobFinished;
    if (usedCompleted.length === 0) {
        return false;
    }
    const workbook = new ExcelJS.Workbook();
    let now = new Date();
    if (overrideStats && overrideStats.date) {
        const d = new Date(overrideStats.date);
        now = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59);
    }
    const reportFileName = `Report_${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}-${String(now.getMinutes()).padStart(2, "0")}-${String(now.getSeconds()).padStart(2, "0")}.xlsx`;
    const reportPath = path.join(reportsFolder, reportFileName);
    const summarySheet = workbook.addWorksheet("Summary");
    const interval1Sheet = workbook.addWorksheet("Interval 1");
    const interval2Sheet = workbook.addWorksheet("Interval 2");
    const interval3Sheet = workbook.addWorksheet("Interval 3");
    summarySheet.addRow(["DAILY PRODUCTIVITY REPORT"]);
    summarySheet.getRow(1).font = {
        bold: true,
        size: 16
    };
    summarySheet.addRow([]);
    summarySheet.addRow(["Jobs Completed", usedCompleted.length]);
    summarySheet.addRow(["Tasks Completed", usedTotalTasks]);
    summarySheet.addRow(["Idle Time", formatDuration(usedIdle)]);
    summarySheet.addRow(["Active Time", formatDuration(usedActive)]);
    const intervalTotals = {
        interval1: {
            jobs: 0,
            tasks: 0,
            idle: 0,
            active: 0
        },
        interval2: {
            jobs: 0,
            tasks: 0,
            idle: 0,
            active: 0
        },
        interval3: {
            jobs: 0,
            tasks: 0,
            idle: 0,
            active: 0
        }
    };
    const tempSorted = usedCompleted.slice().sort((a, b) => (a.started || 0) - (b.started || 0));
    tempSorted.forEach(job => {
        const iv = getIntervalForTimestamp(job.started);
        if (!iv) return;
        intervalTotals[iv].jobs += 1;
        intervalTotals[iv].tasks += job.tasks || 0;
        intervalTotals[iv].idle += job.idle || 0;
        intervalTotals[iv].active += job.active || 0;
    });
    summarySheet.addRow([]);
    summarySheet.addRow(["Interval Summary"]);
    summarySheet.addRow(["Interval", "Jobs", "Tasks", "Idle", "Active"]);
    const headerRow = summarySheet.lastRow.number;
    summarySheet.getRow(headerRow).font = {
        bold: true
    };
    summarySheet.addRow(["Interval 1 (3:00-5:00)", intervalTotals.interval1.jobs, intervalTotals.interval1.tasks, formatDuration(intervalTotals.interval1.idle), formatDuration(intervalTotals.interval1.active)]);
    summarySheet.addRow(["Interval 2 (5:00-7:00)", intervalTotals.interval2.jobs, intervalTotals.interval2.tasks, formatDuration(intervalTotals.interval2.idle), formatDuration(intervalTotals.interval2.active)]);
    summarySheet.addRow(["Interval 3 (7:00-9:30)", intervalTotals.interval3.jobs, intervalTotals.interval3.tasks, formatDuration(intervalTotals.interval3.idle), formatDuration(intervalTotals.interval3.active)]);
    const sortedCompleted = completedJobs.slice().sort((a, b) => (a.started || 0) - (b.started || 0));
    const breakTotalSeconds = usedBreaks.reduce((s, b) => {
        if (b && b.duration) return s + b.duration;
        if (b && b.ended && b.started) return s + Math.floor((b.ended - b.started) / 1000);
        return s;
    }, 0);
    summarySheet.addRow([]);
    summarySheet.addRow(["Totals"]);
    summarySheet.addRow(["Total Jobs", usedCompleted.length]);
    summarySheet.addRow(["Total Tasks", usedTotalTasks]);
    summarySheet.addRow(["Total Idle Time", formatDuration(usedIdle)]);
    summarySheet.addRow(["Total Active Time", formatDuration(usedActive)]);
    summarySheet.addRow(["Last Job Finished", usedLastFinished || "No jobs completed"]);
    summarySheet.addRow(["Break Taken", formatDuration(breakTotalSeconds)]);
    const computedTotals = tempSorted.reduce((acc, j) => {
        acc.jobs += 1;
        acc.tasks += j.tasks || 0;
        acc.idle += j.idle || 0;
        acc.active += j.active || 0;
        acc.duration += j.duration || 0;
        return acc;
    }, {
        jobs: 0,
        tasks: 0,
        idle: 0,
        active: 0,
        duration: 0
    });
    const averageEfficiency = computedTotals.duration > 0 ? Math.round(computedTotals.active / computedTotals.duration * 100) : 100;
    summarySheet.addRow(["Average Efficiency", averageEfficiency + "%"]);
    summarySheet.columns.forEach(column => {
        let max = 15;
        column.eachCell(cell => {
            const len = cell.value ? cell.value.toString().length : 10;
            if (len > max) max = len;
        });
        column.width = max + 3;
    });
    try {
        const r65 = summarySheet.getRow(65);
        for (let i = 1; i <= 8; i++) r65.getCell(i).value = null;
    } catch (e) {}
    summarySheet.addRow([]);
    summarySheet.addRow(["Validation (computed from completedJobs)"]);
    summarySheet.addRow(["Metric", "Computed (s)", "Saved (s)", "Human (computed)"]);
    summarySheet.getRow(summarySheet.lastRow.number).font = {
        bold: true
    };
    summarySheet.addRow(["Idle Seconds", computedTotals.idle, usedIdle, formatDuration(computedTotals.idle)]);
    summarySheet.addRow(["Active Seconds", computedTotals.active, usedActive, formatDuration(computedTotals.active)]);
    summarySheet.addRow(["Total Tracked Seconds", computedTotals.idle + computedTotals.active, usedIdle + usedActive, formatDuration(computedTotals.idle + computedTotals.active)]);
    const reportDate = now.toLocaleDateString('en-US');
    const intervalGroups = {
        interval1: {
            jobs: [],
            tasks: 0,
            idle: 0,
            active: 0
        },
        interval2: {
            jobs: [],
            tasks: 0,
            idle: 0,
            active: 0
        },
        interval3: {
            jobs: [],
            tasks: 0,
            idle: 0,
            active: 0
        }
    };
    sortedCompleted.forEach(job => {
        const iv = getIntervalForTimestamp(job.started);
        if (!iv) return;
        intervalGroups[iv].jobs.push(job);
        intervalGroups[iv].tasks += job.tasks || 0;
        intervalGroups[iv].idle += job.idle || 0;
        intervalGroups[iv].active += job.active || 0;
    });
    populateIntervalSheet(interval1Sheet, intervalGroups.interval1, SHIFT.interval1, reportDate, 'Interval 1');
    populateIntervalSheet(interval2Sheet, intervalGroups.interval2, SHIFT.interval2, reportDate, 'Interval 2');
    populateIntervalSheet(interval3Sheet, intervalGroups.interval3, SHIFT.interval3, reportDate, 'Interval 3 (EOD)');
    [interval1Sheet, interval2Sheet, interval3Sheet].forEach(sheet => {
        sheet.columns.forEach(column => {
            let max = 15;
            column.eachCell(cell => {
                const len = cell.value ? cell.value.toString().length : 10;
                if (len > max) max = len;
            });
            column.width = max + 3;
        });
    });
    await workbook.xlsx.writeFile(reportPath);
    logWithTimestamp(`REPORT GENERATED: ${reportFileName}`);
    return true;

}

// =========================================
// FUNCTION RESET ALL TIME TASKS
// Search: resetAllTimeTasks
// Ver 0.0.5 Alpha || 2026-09-07 || JBallados
// =========================================
function resetAllTimeTasks(reason) {

    allTimeTasks = 0;
    resetCoverageCounters(false);
    saveStats();
    const note = reason ? "AUTO RESET: " + reason : "AUTO RESET: Scheduled";
    logWithTimestamp(note);
    lastLogTimePH = "AUTO RESET";
    scheduleDashboard();
    broadcastToBrowser("reset_counters");

}
