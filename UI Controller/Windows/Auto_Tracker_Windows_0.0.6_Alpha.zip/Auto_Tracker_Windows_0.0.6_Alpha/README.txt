AUTO TRACKER 0.0.6 ALPHA - WINDOWS TEST RELEASE

1. Extract the entire ZIP before running anything.
2. Keep all files and folders together.
3. Run Auto_Tracker.bat.
4. Follow the first-time setup prompts.
5. The setup can check/install Node.js LTS, npm dependencies, ExcelJS, and guide Tampermonkey setup.
6. When prompted, install the Auto Tracker userscript in Tampermonkey.

This is an Alpha test release intended for first-time setup testing.
