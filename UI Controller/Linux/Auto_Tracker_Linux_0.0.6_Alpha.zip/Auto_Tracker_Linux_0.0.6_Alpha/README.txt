AUTO TRACKER 0.0.6 ALPHA - LINUX TEST RELEASE

1. Extract the entire ZIP before running anything.
2. Keep Auto_Tracker.sh and Auto_Tracker.bat in the same folder. The current Linux launcher depends on the BAT file.
3. Ensure Node.js, npm, and Python 3 are installed.
4. In a terminal, run: chmod +x Auto_Tracker.sh
5. Then run: ./Auto_Tracker.sh
6. Install Tampermonkey in your browser and install the bundled Auto Tracker userscript when needed.

Linux first-time dependency automation will be improved after the first release.
This is an Alpha test release intended for first-time setup testing.
