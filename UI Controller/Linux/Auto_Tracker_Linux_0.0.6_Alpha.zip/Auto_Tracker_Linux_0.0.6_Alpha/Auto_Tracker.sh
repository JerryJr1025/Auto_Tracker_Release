#!/usr/bin/env bash
# Ver 0.0.5 Alpha || 2026-09-07 || JBallados
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${SCRIPT_DIR}"
BATCH_FILE="${SCRIPT_DIR}/Auto_Tracker.bat"

cd "$TARGET_DIR"

if [[ ! -f "$BATCH_FILE" ]]; then
    echo "[ERROR] Auto_Tracker.bat not found: $BATCH_FILE"
    exit 1
fi

BACKUP_DIR="${TARGET_DIR}/Backups"
BACKUP_TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"
CURRENT_BACKUP="${BACKUP_DIR}/${BACKUP_TIMESTAMP}"

mkdir -p "$CURRENT_BACKUP"

if [[ -f "${TARGET_DIR}/server.js" ]]; then
    cp -f "${TARGET_DIR}/server.js" "${CURRENT_BACKUP}/server.js"
fi

if [[ -f "${TARGET_DIR}/stats.json" ]]; then
    cp -f "${TARGET_DIR}/stats.json" "${CURRENT_BACKUP}/stats.json"
fi

if [[ -f "${TARGET_DIR}/dashboard.html" ]]; then
    cp -f "${TARGET_DIR}/dashboard.html" "${CURRENT_BACKUP}/dashboard.html"
fi

if [[ -f "${TARGET_DIR}/dashboard.js" ]]; then
    cp -f "${TARGET_DIR}/dashboard.js" "${CURRENT_BACKUP}/dashboard.js"
fi

if [[ -f "${TARGET_DIR}/dashboard.css" ]]; then
    cp -f "${TARGET_DIR}/dashboard.css" "${CURRENT_BACKUP}/dashboard.css"
fi

if [[ -d "${TARGET_DIR}/Logs" ]]; then
    cp -a "${TARGET_DIR}/Logs" "${CURRENT_BACKUP}/"
fi

if [[ -d "${TARGET_DIR}/Reports" ]]; then
    cp -a "${TARGET_DIR}/Reports" "${CURRENT_BACKUP}/"
fi

echo "Backup: ${CURRENT_BACKUP}"

python3 - "$BATCH_FILE" "${TARGET_DIR}/server.js" <<'PY'
import sys
from pathlib import Path

src_path = Path(sys.argv[1])
out_path = Path(sys.argv[2])

lines = src_path.read_text(
    encoding="utf-8",
    errors="ignore"
).splitlines(keepends=True)

marker_index = None

for i, line in enumerate(lines):
    if line.strip() == "___JS_START___":
        marker_index = i
        break

if marker_index is None:
    raise SystemExit(
        "[ERROR] JavaScript start marker was not found!"
    )

js = "".join(lines[marker_index + 1:])

if not js.strip():
    raise SystemExit(
        "[ERROR] JavaScript section is empty!"
    )

out_path.write_text(
    js,
    encoding="utf-8"
)

PY

if [[ ! -f package.json ]]; then
    cat > package.json <<'JSON'
{
  "name": "jobtrackerserver",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "exceljs": "^4.4.0",
	"sqlite3":  "^5.1.7"
  }
}
JSON
fi

if ! command -v node >/dev/null 2>&1; then
    echo "[ERROR] Node.js is required but not installed."
    exit 1
fi

PORT=9000
if command -v fuser >/dev/null 2>&1; then
    PIDS=$(fuser -n tcp "$PORT" 2>/dev/null || true)
    if [[ -n "$PIDS" ]]; then
        echo "[WARN] Port $PORT is already in use by PID(s): $PIDS"
        echo "The previous tracker process may still be running."
        read -rp "Stop the old process and continue? [Y/n]: " answer
        case "${answer:-Y}" in
            y|Y|yes|YES)
                kill $PIDS 2>/dev/null || true
                sleep 1
            ;;
            *)
                echo "Please free port $PORT and run the tracker again."
                exit 1
            ;;
    esac
fi
fi

npm install --silent >/dev/null 2>&1 || npm install --silent

while true; do

    node server.js

    echo "Server stopped."

    echo "[R] Restart Server"
    echo "[Q] Quit"

    read -rp "Select: " choice || choice="Q"
    choice="${choice^^}"

    if [[ "$choice" == "Q" ]]; then
        exit 0
    elif [[ "$choice" != "R" ]]; then
        echo "Invalid choice. Please enter R or Q."
    fi
done

